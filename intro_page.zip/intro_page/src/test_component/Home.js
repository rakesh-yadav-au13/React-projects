import React from 'react'
import "./Home.css";
const Home = () => {
    return (
            <div className="search_container">
                <div className="heading">
                    My Home Page
                </div>
            </div>
    )
}

export default Home;
