import React from 'react'
import "./Footer.css"
const Footer = (props) => {
    return (
        <footer>
            <div>&copy; Devolper Pennel {props.year} </div>
        </footer>

    )
}

export default Footer;
